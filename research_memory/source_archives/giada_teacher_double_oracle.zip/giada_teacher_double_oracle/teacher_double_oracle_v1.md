# GIADA Task 0.4 — Ca_HVA double oracle

- Valid: **True**
- Cases: **7360**
- Failures: **0**
- Maximum absolute error: **2.220e-16**

## Independence contract

The formula oracle interprets assignments extracted from `Ca_HVA.mod`. The NEURON oracle advances the authentic compiled `DERIVATIVE states` block through one supported fixed NEURON step on an electrically silent section (`gCa_HVAbar=0`, no other membrane mechanisms). It does not reuse the Python formula. This replaces the preregistered direct HOC procedure call, which is not exported by the Kaggle NEURON/NMODL runtime.

## Acceptance

Every case must satisfy `abs(error) <= 1.0e-10 + 1.0e-10 * abs(reference)`.
