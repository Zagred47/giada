#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;

extern "C" void _Ca_HVA_reg(void);

extern "C" void modl_reg() {
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_teacher_double_oracle/compiled_mechanism/Ca_HVA.mod\"");
    fprintf(stderr, "\n");
  }
  _Ca_HVA_reg();
}
