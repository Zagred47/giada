#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;
#if defined(__cplusplus)
extern "C" {
#endif

extern void _Nap_Et2_reg(void);
extern void _NaTa_t_reg(void);
extern void _NaTs2_t_reg(void);

void modl_reg() {
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task27_current_supervision_c072e69_d4a22842/sodium/native/Nap_Et2.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task27_current_supervision_c072e69_d4a22842/sodium/native/NaTa_t.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task27_current_supervision_c072e69_d4a22842/sodium/native/NaTs2_t.mod\"");
    fprintf(stderr, "\n");
  }
  _Nap_Et2_reg();
  _NaTa_t_reg();
  _NaTs2_t_reg();
}

#if defined(__cplusplus)
}
#endif
