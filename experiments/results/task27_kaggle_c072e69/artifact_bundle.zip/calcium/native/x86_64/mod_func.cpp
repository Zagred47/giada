#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;
#if defined(__cplusplus)
extern "C" {
#endif

extern void _Ca_HVA_reg(void);
extern void _Ca_LVAst_reg(void);

void modl_reg() {
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task27_current_supervision_c072e69_d4a22842/calcium/native/Ca_HVA.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task27_current_supervision_c072e69_d4a22842/calcium/native/Ca_LVAst.mod\"");
    fprintf(stderr, "\n");
  }
  _Ca_HVA_reg();
  _Ca_LVAst_reg();
}

#if defined(__cplusplus)
}
#endif
