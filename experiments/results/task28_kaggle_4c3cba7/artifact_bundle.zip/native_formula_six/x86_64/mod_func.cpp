#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;
#if defined(__cplusplus)
extern "C" {
#endif

extern void _Ih_reg(void);
extern void _Im_reg(void);
extern void _K_Pst_reg(void);
extern void _K_Tst_reg(void);
extern void _SK_E2_reg(void);
extern void _SKv3_1_reg(void);

void modl_reg() {
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task28_ionic_block_4c3cba7_9cc64c9c/native_formula_six/Ih.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task28_ionic_block_4c3cba7_9cc64c9c/native_formula_six/Im.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task28_ionic_block_4c3cba7_9cc64c9c/native_formula_six/K_Pst.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task28_ionic_block_4c3cba7_9cc64c9c/native_formula_six/K_Tst.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task28_ionic_block_4c3cba7_9cc64c9c/native_formula_six/SK_E2.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task28_ionic_block_4c3cba7_9cc64c9c/native_formula_six/SKv3_1.mod\"");
    fprintf(stderr, "\n");
  }
  _Ih_reg();
  _Im_reg();
  _K_Pst_reg();
  _K_Tst_reg();
  _SK_E2_reg();
  _SKv3_1_reg();
}

#if defined(__cplusplus)
}
#endif
