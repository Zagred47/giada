NEURON {
    SUFFIX giada_ca_inject
    USEION ca WRITE ica
    RANGE amp
}
UNITS { (mA) = (milliamp) }
PARAMETER { amp = 0 (mA/cm2) }
ASSIGNED { ica (mA/cm2) }
BREAKPOINT { ica = amp }
