#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;
#if defined(__cplusplus)
extern "C" {
#endif

extern void _CaDynamics_E2_reg(void);
extern void _giada_ca_inject_reg(void);
extern void _SK_E2_reg(void);

void modl_reg() {
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_iv_b_8b3a4e5_87eeb94c/compiled_calcium/CaDynamics_E2.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_iv_b_8b3a4e5_87eeb94c/compiled_calcium/giada_ca_inject.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_iv_b_8b3a4e5_87eeb94c/compiled_calcium/SK_E2.mod\"");
    fprintf(stderr, "\n");
  }
  _CaDynamics_E2_reg();
  _giada_ca_inject_reg();
  _SK_E2_reg();
}

#if defined(__cplusplus)
}
#endif
