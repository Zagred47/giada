#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;
#if defined(__cplusplus)
extern "C" {
#endif

extern void _ProbAMPANMDA_EMS_reg(void);
extern void _ProbGABAAB_EMS_reg(void);

void modl_reg() {
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_iv_c1_f28d3bc_aca9ac69/compiled_synapses/ProbAMPANMDA_EMS.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_iv_c1_f28d3bc_aca9ac69/compiled_synapses/ProbGABAAB_EMS.mod\"");
    fprintf(stderr, "\n");
  }
  _ProbAMPANMDA_EMS_reg();
  _ProbGABAAB_EMS_reg();
}

#if defined(__cplusplus)
}
#endif
