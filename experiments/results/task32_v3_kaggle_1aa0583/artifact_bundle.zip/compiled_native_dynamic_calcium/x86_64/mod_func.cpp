#include <stdio.h>
#include "hocdec.h"
extern int nrnmpi_myid;
extern int nrn_nobanner_;
#if defined(__cplusplus)
extern "C" {
#endif

extern void _CaDynamics_E2_reg(void);
extern void _Ca_HVA_reg(void);
extern void _Ca_LVAst_reg(void);
extern void _Ih_reg(void);
extern void _Im_reg(void);
extern void _K_Pst_reg(void);
extern void _K_Tst_reg(void);
extern void _Nap_Et2_reg(void);
extern void _NaTa_t_reg(void);
extern void _NaTs2_t_reg(void);
extern void _SK_E2_reg(void);
extern void _SKv3_1_reg(void);

void modl_reg() {
  if (!nrn_nobanner_) if (nrnmpi_myid < 1) {
    fprintf(stderr, "Additional mechanisms from files\n");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/CaDynamics_E2.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/Ca_HVA.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/Ca_LVAst.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/Ih.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/Im.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/K_Pst.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/K_Tst.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/Nap_Et2.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/NaTa_t.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/NaTs2_t.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/SK_E2.mod\"");
    fprintf(stderr, " \"/kaggle/working/artifacts/giada_task32_1aa0583_4ebf4745/compiled_native_dynamic_calcium/SKv3_1.mod\"");
    fprintf(stderr, "\n");
  }
  _CaDynamics_E2_reg();
  _Ca_HVA_reg();
  _Ca_LVAst_reg();
  _Ih_reg();
  _Im_reg();
  _K_Pst_reg();
  _K_Tst_reg();
  _Nap_Et2_reg();
  _NaTa_t_reg();
  _NaTs2_t_reg();
  _SK_E2_reg();
  _SKv3_1_reg();
}

#if defined(__cplusplus)
}
#endif
